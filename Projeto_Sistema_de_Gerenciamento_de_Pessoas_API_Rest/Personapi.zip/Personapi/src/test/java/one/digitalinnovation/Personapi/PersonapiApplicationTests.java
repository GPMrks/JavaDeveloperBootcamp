package one.digitalinnovation.Personapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
